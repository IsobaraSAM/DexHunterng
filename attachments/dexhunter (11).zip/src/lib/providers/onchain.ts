import { IDexHunterProvider } from "./types";
import { TokenPair } from "../../types";
import { normalizeChainName } from "../dexPriority";

async function fetchJsonWithTimeout(url: string, timeoutMs = 4000, externalSignal?: AbortSignal): Promise<any> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  const onAbort = () => controller.abort();
  if (externalSignal) {
    if (externalSignal.aborted) {
      clearTimeout(timeoutId);
      return null;
    }
    externalSignal.addEventListener("abort", onAbort, { once: true });
  }

  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (externalSignal) externalSignal.removeEventListener("abort", onAbort);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    clearTimeout(timeoutId);
    if (externalSignal) externalSignal.removeEventListener("abort", onAbort);
    return null;
  }
}

export class OnChainProvider implements IDexHunterProvider {
  name = "OnChain";

  async searchTokens(query: string, signal?: AbortSignal): Promise<Partial<TokenPair>[]> {
    const clean = query.trim();
    if (clean.length >= 28 && !clean.includes(" ")) {
      return this.getTokenByAddress(clean, undefined, signal);
    }
    return [];
  }

  async getTokenByAddress(address: string, chainId?: string, signal?: AbortSignal): Promise<Partial<TokenPair>[]> {
    const cleanAddr = address.trim();
    if (!cleanAddr) return [];

    const isEvm = cleanAddr.startsWith("0x") && cleanAddr.length === 42;
    const isSolana = !cleanAddr.startsWith("0x") && cleanAddr.length >= 32 && cleanAddr.length <= 44;

    if (!isEvm && !isSolana) return [];

    const detectedChain = chainId || (isSolana ? "solana" : "ethereum");

    try {
      // Execute on-chain resolver and secondary DexScreener indexer concurrently with Promise.allSettled
      const queries: Promise<any>[] = [
        fetchJsonWithTimeout(
          `https://api.dexscreener.com/latest/dex/tokens/${cleanAddr}`,
          5000,
          signal
        ),
      ];

      if (isSolana) {
        queries.unshift(
          fetchJsonWithTimeout(
            `/api/pump-resolve?mint=${encodeURIComponent(cleanAddr)}`,
            5000,
            signal
          )
        );
      }

      const settled = await Promise.allSettled(queries);

      // 1. Check Solana direct resolver result first if queried
      if (isSolana && settled[0].status === "fulfilled" && settled[0].value) {
        const resolveRes = settled[0].value;
        if (resolveRes.status && resolveRes.status !== "INVALID_MINT" && resolveRes.status !== "NOT_PUMPFUN_BONDING_CURVE" && resolveRes.token) {
          const t = resolveRes.token;
          const isGraduated = Boolean(t.complete || t.isGraduated || t.marketStage === "pumpswap" || t.marketStage === "graduated");
          const pairAddress = (isGraduated && t.pumpSwapPool) ? t.pumpSwapPool : (t.bondingCurvePda || cleanAddr);
          return [
            {
              chainId: "solana",
              dexId: isGraduated ? "pumpswap" : "pumpfun",
              primaryDex: isGraduated ? "PumpSwap" : undefined,
              launchPlatform: "Pump.fun",
              url: `https://pump.fun/coin/${cleanAddr}`,
              pairAddress,
              baseToken: {
                address: cleanAddr,
                name: t.tokenName || "Pump Token",
                symbol: t.tokenSymbol || "PUMP",
              },
              quoteToken: {
                address: "So11111111111111111111111111111111111111112",
                name: "Wrapped SOL",
                symbol: "SOL",
              },
              priceNative: t.spotPriceSol || "0",
              priceUsd: t.spotPriceUsd || "0",
              marketCap: t.marketCapUsd || 0,
              fdv: t.fdvUsd || t.marketCapUsd || 0,
              liquidity: {
                usd: t.liquidityUsd !== undefined ? t.liquidityUsd : undefined,
              },
              totalLiquidityUsd: t.liquidityUsd !== undefined ? t.liquidityUsd : undefined,
              volume: undefined,
              totalVolume24h: undefined,
              pairCreatedAt: t.createdAt || undefined,
              info: {
                imageUrl: t.imageUrl || undefined,
                websites: t.website ? [{ type: "website", label: "Website", url: t.website.startsWith("http") ? t.website : `https://${t.website}` }] : [],
                socials: [
                  ...(t.twitter ? [{ type: "twitter", url: t.twitter.startsWith("http") ? t.twitter : `https://x.com/${t.twitter.replace(/^@/, "")}` }] : []),
                  ...(t.telegram ? [{ type: "telegram", url: t.telegram.startsWith("http") ? t.telegram : `https://t.me/${t.telegram.replace(/^@/, "")}` }] : []),
                ],
              },
              primaryProvider: this.name,
              sources: isGraduated ? ["PumpSwap", "OnChain (Solana RPC)"] : ["OnChain (Solana RPC)"],
              dexes: isGraduated ? ["PumpSwap"] : [],
              bondingCurvePda: t.bondingCurvePda,
              bondingProgress: isGraduated ? 100 : (t.bondingProgress || 0),
              isBondingCurve: !isGraduated,
              isGraduated,
              complete: isGraduated || Boolean(t.complete),
              marketStage: isGraduated ? "pumpswap" : "bonding_curve",
              pumpSwapPool: t.pumpSwapPool,
              pumpswap_pool: t.pumpSwapPool,
              pairs: isGraduated ? [
                {
                  chainId: "solana",
                  pairAddress,
                  dexName: "PumpSwap",
                  dexId: "pumpswap",
                  baseToken: {
                    address: cleanAddr,
                    name: t.tokenName || "Pump Token",
                    symbol: t.tokenSymbol || "PUMP",
                  },
                  quoteToken: {
                    address: "So11111111111111111111111111111111111111112",
                    name: "Wrapped SOL",
                    symbol: "SOL",
                  },
                  priceUsd: t.spotPriceUsd || "0",
                  liquidityUsd: t.liquidityUsd,
                },
              ] : undefined,
              realSolReservesFormatted: t.realSolReservesFormatted,
              virtualTokenReserves: t.virtualTokenReserves,
              virtualSolReserves: t.virtualSolReserves,
              realTokenReserves: t.realTokenReserves,
              realSolReserves: t.realSolReserves,
              tokenTotalSupply: t.tokenTotalSupply,
            },
          ];
        }
      }

      // 2. Check DexScreener token endpoint result
      const dexSettledIndex = isSolana ? 1 : 0;
      if (settled[dexSettledIndex] && settled[dexSettledIndex].status === "fulfilled" && settled[dexSettledIndex].value) {
        const dexRes = settled[dexSettledIndex].value;
        if (Array.isArray(dexRes?.pairs) && dexRes.pairs.length > 0) {
          const normChain = chainId ? normalizeChainName(chainId) : undefined;
          return dexRes.pairs
            .filter((p: any) => !normChain || normChain === "all" || normalizeChainName(p.chainId) === normChain)
            .map((p: any) => ({
              ...p,
              primaryProvider: this.name,
            }));
        }
      }

      return [];
    } catch {
      return [];
    }
  }

  async discoverTokens(_mode: "trending" | "latest", _signal?: AbortSignal, _chainId?: string): Promise<Partial<TokenPair>[]> {
    return [];
  }
}
