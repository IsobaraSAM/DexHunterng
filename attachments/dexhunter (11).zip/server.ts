import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import pumpfunNewHandler from "./api/pumpfun-new.js";
import tokenHoldersHandler from "./api/token-holders.js";
import pumpResolveHandler from "./api/pump-resolve.js";
import pumpFreshHandler from "./api/pump-fresh.js";
import pumpfunDebugHandler from "./api/pumpfun-debug.js";
import pumpfunDiagnosticHandler from "./api/pumpfun-diagnostic.js";
import { pumpIndexer } from "./api/pump-engine.js";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: Date.now() });
  });

  // API Route for direct on-chain Pump.fun bonding-curve resolution
  app.get("/api/pump-resolve", async (req, res) => {
    try {
      await pumpResolveHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // Alias /api/pump-token
  app.get("/api/pump-token", async (req, res) => {
    try {
      await pumpResolveHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // API Route for live on-chain discovered Fresh Mints
  app.get("/api/pump-fresh", async (req, res) => {
    try {
      await pumpFreshHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // API Route for Pump.fun lifecycle diagnostic (one-token resolver)
  app.get("/api/pumpfun-debug", async (req, res) => {
    try {
      await pumpfunDebugHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // API Route for comprehensive Pump.fun Metaplex & IPFS metadata diagnostic & audit trail
  app.get("/api/pumpfun-diagnostic", async (req, res) => {
    try {
      await pumpfunDiagnosticHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  app.get("/api/pump-diagnostic", async (req, res) => {
    try {
      await pumpfunDiagnosticHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  app.get("/api/pumpfun-audit", async (req, res) => {
    try {
      await pumpfunDiagnosticHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  app.get("/api/pump-audit", async (req, res) => {
    try {
      await pumpfunDiagnosticHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // API Route for Pump.fun fresh mints via Moralis proxy
  app.get("/api/pumpfun-new", async (req, res) => {
    try {
      await pumpfunNewHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // API Route for Solana token top holders & concentration via Moralis proxy
  app.get("/api/token-holders", async (req, res) => {
    try {
      await tokenHoldersHandler(req, res);
    } catch (err: any) {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Internal server error" });
      }
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DexHunter server running on http://0.0.0.0:${PORT}`);
    // Start continuous on-chain Pump.fun discovery & backfill indexer
    pumpIndexer.start().catch((err) => {
      console.error("[Pump Indexer] Startup error:", err);
    });
  });
}

startServer();
